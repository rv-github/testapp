import { LoaderService } from './../../services/loader.service';
import { AuthService } from './../../services/auth.service';
import { Component, OnInit, Input } from '@angular/core';
import { StateService } from '@uirouter/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  selectedTab = 'HOME';
  @Input() public enableNav;
  constructor(
    private StatesService: StateService,
    private authService: AuthService,
    private loaderService: LoaderService
  ) {}

  ngOnInit() {}

  navClickHandler(value: string) {
    this.selectedTab = value;
    switch (value) {
      case 'HOME': {
        this.StatesService.go('Home');
        break;
      }
      case 'LOGOUT': {
        this.logOutHandler();
        break;
      }
      case 'YOUR ACTION': {
        this.yourActionHandler();
        break;
      }
    }
  }

  logOutHandler() {
    this.authService
      .doLogout()
      .then(() => {
        this.StatesService.go('Login');
        this.enableNav = false;
      })
      .catch(err => {
        console.log(err);
        this.StatesService.go('Login');
        this.enableNav = false;
      });
  }

  yourActionHandler(){
    // TODO
  }
}
