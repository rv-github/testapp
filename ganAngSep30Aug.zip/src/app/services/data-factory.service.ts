import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataFactoryService {

  sessionObject: any = {};

  constructor() {}

  setValue(key, val) {
    this.sessionObject[key] = val;
  }
  getValue(key) {
    return this.sessionObject[key];
  }
}
