/* angular imports */
import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs/';

@Injectable({
  providedIn: 'root'
})
export class SubscriptionService {
  public ObservableObject: { [s: string]: BehaviorSubject<any> } = {};

  subscribe(name: string): Observable<any> {
    return new Observable(observer => {
      this.ObservableObject[name] = new BehaviorSubject(null);
      this.ObservableObject[name].subscribe(_data => {
        observer.next(_data);
      });
    });
  }

  publish(name, data: any) {
    this.ObservableObject[name].next(data);
  }
}
