import { Uservo } from './../model/uservo';
import { map } from 'rxjs/operators';
import { Observable, BehaviorSubject, Subject } from 'rxjs/';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import * as firebase from 'firebase/app';
import { User } from 'firebase';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { switchMap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  currentDate = firebase.firestore.FieldValue.serverTimestamp();
  allUsersFirestoreCollection: AngularFirestoreCollection<any> = null;
  users: any = null;
  userRecord: Uservo;
  queryObservable: Observable<any[]>;
  sizeFilter$ = new Subject<string|null>();
  constructor(public afAuth: AngularFireAuth, public db: AngularFirestore) {
    console.log(this.currentDate);
    // identify todays server date
    this.db.collection('date').doc('1').update({name: this.currentDate});
  }

  getUserLoginStatus() {
    const promise = new Promise((resolve, reject) => {
      this.afAuth.authState.subscribe(user => {
        if (user) {
          this.userInitialization(user);
          resolve();
        } else {
          reject();
        }
      });
    });
    return promise;
  }

  userInitialization(user){
    this.db.collection('users').doc(user.email).ref.get().then(doc => {
      if (doc.exists) {
        console.log('Document data:', doc.data());
      } else {
         console.log('No such document!');
         this.createUserRecord(user);
      }
    }).catch(error => {
      console.log('Error getting document, userInitialization:', error);
    });
  }

  createUserRecord(user) {
    console.log('Creating User Record');
    if(user.email == 'satyawan.chorge@gmail.com' || user.email == 'satyawanchorge@gmail.com'){
      this.userRecord = {name: user.displayName, role : 'admin', email: user.email, rank: 1, points: 0, date: this.currentDate};
    } else{
      this.userRecord = {name: user.displayName, role : 'contestant', email: user.email, rank: 1, points: 0, date: this.currentDate};
    }
    this.db.collection('users').doc(user.email).set(this.userRecord);
  }

  fetchQuery() {
    this.queryObservable = this.sizeFilter$.pipe(
      switchMap(size =>
        this.db.collection('users', ref => ref.where('email', '==', size)).snapshotChanges()
      )
    );
    this.queryObservable.subscribe(result => {
      console.log(result);
    });
    this.sizeFilter$.next('test@mail.com');
  }

  doGoogleLogin() {
    const provider = new firebase.auth.GoogleAuthProvider();
    provider.addScope('profile');
    provider.addScope('email');
    this.afAuth.auth.signInWithRedirect(provider);
  }

  doLogout() {
    const promise = new Promise((resolve, reject) => {
      if (firebase.auth().currentUser) {
        this.afAuth.auth.signOut().then(() => {
            resolve();
        }).catch(err => {
            reject(err);
        });
      } else {
          reject();
      }
    });
    return promise;
  }

  getUsersList(): any {
    this.allUsersFirestoreCollection = this.db.collection('users', ref => ref.where('email', '==', 'ravindra.chorge@gmail.com'));
    this.allUsersFirestoreCollection.snapshotChanges().pipe(
      map(changes =>
        changes.map(c =>
          ({ key: c.payload.doc.id, ...c.payload.doc.data() })
        )
      )
    ).subscribe(users => {
      this.users = users;
      console.log(this.users);
    });
    return this.users;
  }

}
