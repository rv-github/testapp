import { map, finalize } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import * as _ from 'underscore';
import { HttpClient } from '@angular/common/http';
import { formatDate } from '@angular/common';
import { AngularFireStorage } from '@angular/fire/storage';
import { Observable } from 'rxjs';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    constructor(private authService: AuthService, private httpClient: HttpClient, private storage: AngularFireStorage) { }
    userDetail = this.authService.userDetails;
    todayDate = formatDate(new Date(this.authService.todayDate), 'EEEE, dd MMM yyyy', 'en');
    dayCount:string;
    currentPage;
    //totalPages = this.authService.todayDate.getDate() - 1;
    totalPages = 1;
    pager: any = {};
    pagedItems: any[];
    file:File;
    fileSize;
    fileUnit = "";
    fileName = 'Choose file..';
    fileError = false;
    fileSuccess = false;
    btnError = true;
    base64textString:String="";
    isPhotoUploaded = true;

    users: any;

    ngOnInit() {
        if (this.totalPages < 1 || this.totalPages > 11) {
            this.totalPages = 0;
        }
        if (this.authService.todayDate.getDate()) {
            // initialize to page 1
            this.setPage(this.totalPages);
        } else {
            // TODO
            console.log('Logout Handler');
        }
    }

    setPage(page: number) {
        if (page < 1 || page > 11) {
            //return;
            page = 1;
        }
        // get pager object from service
        this.pager = this.getPager(page);
        this.dayCount = this.pager.dayCount;
        console.log(this.pager);
    }

    getPager(currentPage: number = 1) {
        this.currentPage = currentPage;
        // calculate total pages
        let totalPages = this.totalPages;

        let startPage: number, endPage: number, dayCount: string;

        if (totalPages <= 5) {
            startPage = 1;
            endPage = totalPages;
        } else {
            if (currentPage <= 3) {
                startPage = 1;
                endPage = 5;
            } else if (currentPage + 1 >= totalPages) {
                startPage = totalPages - 4;
                endPage = totalPages;
            } else {
                startPage = currentPage - 2;
                endPage = currentPage + 2;
            }
        }
        if(currentPage == 1)
        dayCount = 'Day 1 - Monday, 2nd September'
        else if(currentPage == 2)
        dayCount = 'Day 2 - Tuesday, 3rd September'
        else if(currentPage == 3)
        dayCount = 'Day 3 - Wednesday, 4th September'
        else if(currentPage == 4)
        dayCount = 'Day 4 - Thursday, 5th September'
        else if(currentPage == 5)
        dayCount = 'Day 5 - Friday, 6th September'
        else if(currentPage == 6)
        dayCount = 'Day 6 - Saturday, 7th September'
        else if(currentPage == 7)
        dayCount = 'Day 7 - Sunday, 8th September'
        else if(currentPage == 8)
        dayCount = 'Day 8 - Monday, 9th September'
        else if(currentPage == 9)
        dayCount = 'Day 9 - Tuesday, 10th September'
        else if(currentPage == 10)
        dayCount = 'Day 10 - Wednesday, 11th September'
        else if(currentPage == 11)
        dayCount = 'Day 11 - Thursday, 12th September'
        else
        dayCount = 'Hello..!'
        // create an array of pages to ng-repeat in the pager control
        let pages = _.range(startPage, endPage + 1);
        // return object with all pager properties required by the view
        return {
            currentPage: currentPage,
            totalPages: totalPages,
            startPage: startPage,
            endPage: endPage,
            pages: pages,
            dayCount:dayCount
        };
    }

    fileChangeEvent(fileInput: any) {
        if (fileInput.target.files && fileInput.target.files[0]) {
            let file = fileInput.target.files[0];
            this.fileName = file.name;
            const size = file.size;
            if (size < 1000) {
            this.fileSize = size;
            this.fileUnit = "bytes";
            } else if (size < 1000*1000) {
            this.fileSize = size / 1000;
            this.fileUnit = "kb";
            } else if (size < 1000*1000*1000) {
            this.fileSize = size / 1000 / 1000;
            this.fileUnit = "mb";
            } else {
            this.fileSize = size / 1000 /1000 /1000;
            this.fileUnit = "gb";
            }

            if(file.type.indexOf('image/') < 0 || ((this.fileUnit == 'mb' || this.fileUnit == 'gb') && this.fileSize > 4))
            this.fileError = true;
            else
            this.fileError = false;

            this.btnError = this.fileError || this.fileName == 'Choose file..';
            if(!this.btnError)
            this.file = file;
        }
    }

    uploadPercent: Observable<number>;
    downloadURL: Observable<string>;
    uploadFileHandler(){
        console.log('uploadFileHandler');
        const file = this.file;
        const filePath = `day${this.currentPage}/${this.userDetail.email}_${new Date().getTime()}_${file.name}`;
        const ref = this.storage.ref(filePath);
        //const task = this.storage.upload(filePath, file, { customMetadata: { blah: 'blah' } });
        const task = ref.put(file);

        // observe percentage changes
        this.uploadPercent = task.percentageChanges();
        // get notified when the download URL is available
        task.snapshotChanges().pipe(
            finalize(() => this.downloadURL = ref.getDownloadURL()  )).subscribe(fileStatus => {
            if (fileStatus) {
            console.log(fileStatus);
            console.log('File URl half', this.downloadURL);    
            if(fileStatus.state === 'running' && (fileStatus.bytesTransferred >= fileStatus.totalBytes)){
                console.log('File Uploaded');
                console.log('File URl', this.downloadURL);
                console.log('File URl ref', ref.getDownloadURL);
                //console.log('File URl ref()', ref.getDownloadURL());
                const collectionId = 'day'+this.currentPage;
                this.authService.handlePhotoRecords(collectionId, this.userDetail.email, filePath);
            }

            
            }
        })

    }

    getUsersList() {
        this.users = this.authService.getUsersList();
        console.log(this.users);
    }
}

