import { AuthService } from './services/auth.service';
import { Component, OnInit, Input } from '@angular/core';
import { StateService, any } from '@uirouter/core';
import { LoaderService } from './services/loader.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'ganAngSep';
  showNavigation = false;
  showLoader = true;
  constructor(
    private authService: AuthService,
    private StatesService: StateService,
    private loaderService: LoaderService
  ) {
    this.loaderService.isLoading.subscribe(flag => {
      console.log(flag);
      this.showLoader = flag;
    });
  }

  ngOnInit() {
    const currentScope = this;
    this.authService.getUserLoginStatus().then(() => {
            this.authService.userInitialization().then(() => {
                this.authService.getTodaysDate().then(() => {
                    console.log('got todays date', this.authService.userDetails.displayName);
                    this.loaderService.isLoading.next(false);
                    this.StatesService.go('Home');
                    this.showNavigation = true;
              })
              .catch(() => {
                this.logOutHandler();
              });  
          })
          .catch(() => {
            this.logOutHandler();
          });  
      })
      .catch(() => {
        this.logOutHandler();
      });
  }

  logOutHandler(){
    this.loaderService.isLoading.next(false);
    this.showNavigation = false;
    this.StatesService.go('Login');
  }

 

 
 
}
