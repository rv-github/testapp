export interface Uservo  {
  role: string | '';
  name: string | '';
  email: string | '';
  rank: number;
  points: number;
  date: any;
  photos?: Array<Photovo>;
}

export interface Photovo  {
  date: any;
  dayCount: number;
  showIdentity: false;
  marks: number;
  owner: string | '';
  photoPath: string;
  photoUrl?: any;
  likes?: number;
  dislikes?: number;
  photoOfTheDay?: boolean | false;
}
