// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyD4XKSKlbE9voR6UlB1GnrJqvtPY5eiDlE',
    authDomain: 'ganangsept-bd98d.firebaseapp.com',
    databaseURL: 'https://ganangsept-bd98d.firebaseio.com',
    projectId: 'ganangsept-bd98d',
    storageBucket: 'ganangsept-bd98d.appspot.com',
    messagingSenderId: '1059890255792',
    appId: '1:1059890255792:web:33613c5093a7619d'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

