import { map } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import * as _ from 'underscore';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private authService: AuthService, private httpClient: HttpClient) { }
  userDetail = this.authService.userDetails;
  users: any;
  todayDate = this.authService.todayDate;

  private allItems;

 // pager object
 pager: any = {};

 // paged items
 pagedItems: any[];

  ngOnInit() {
     // initialize to page 1
     this.setPage(1);
  }

  getUsersList() {
    this.users = this.authService.getUsersList();
    console.log(this.users);
  }

  deleteUsers() {
    //this.authService.deleteAll();
  }

  setPage(page: number) {
    if (page < 1 || page > this.pager.totalPages) {
        return;
    }

    // get pager object from service
    this.pager = this.getPager(page);
  console.log(this.pager);


  }

  getPager(currentPage: number = 1) {
    // calculate total pages
    let totalPages = 11;

    let startPage: number, endPage: number;

    if (totalPages <= 5) {
        startPage = 1;
        endPage = totalPages;
    } else {
        if (currentPage <= 3) {
            startPage = 1;
            endPage = 5;
        } else if (currentPage + 1 >= totalPages) {
            startPage = totalPages - 4;
            endPage = totalPages;
        } else {
            startPage = currentPage - 2;
            endPage = currentPage+2;
        }
    }

    // create an array of pages to ng-repeat in the pager control
    let pages = _.range(startPage, endPage + 1);

    // return object with all pager properties required by the view
    return {
        currentPage: currentPage,
        totalPages: totalPages,
        startPage: startPage,
        endPage: endPage,
        pages: pages
    };
  }
}

