export interface Uservo  {
  role: string | '';
  name: string | '';
  email: string | '';
  rank: number;
  points: number;
  date: any;
  photos?: Array<Photos>;
}

export interface Photos  {
  date: string | '';
  day1: string | '';
  showIdentity: boolean | false;
  marks: number;
  owner: string | '';
  likes: number;
  dislikes: number;
  photoOfTheDay: boolean | false;
}
