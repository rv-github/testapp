import { LoginComponent } from './comps/login/login.component';
// angular imports
import { NgModule, NgModuleFactoryLoader, SystemJsNgModuleLoader } from '@angular/core';

// other library imports
import { UIRouterModule } from '@uirouter/angular';
import { HomeComponent } from './comps/home/home.component';

const ROOT_ROUTE = [
  {
    name: 'Login',
    component: LoginComponent
  },
  {
    name: 'Home',
    component: HomeComponent
  }
];


@NgModule({
  declarations: [],
  imports: [UIRouterModule.forRoot({ states: ROOT_ROUTE, useHash: false })],
  providers: [],
  exports: [UIRouterModule]
})
export class RoutingModule { }
