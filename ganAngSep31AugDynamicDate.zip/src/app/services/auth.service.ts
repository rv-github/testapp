import { Uservo } from './../model/uservo';
import { map } from 'rxjs/operators';
import { Observable, BehaviorSubject, Subject, Timestamp } from 'rxjs/';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import * as firebase from 'firebase/app';
import { User } from 'firebase';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { switchMap } from 'rxjs/operators';
import { formatDate } from '@angular/common';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  currentTimestamp = firebase.firestore.FieldValue.serverTimestamp();
  todayDate:Date;
  userRecord: Uservo;
  userDetails:User;

  allUsersFirestoreCollection: AngularFirestoreCollection<any> = null;
  users: any = null;
  queryObservable: Observable<any[]>;
  sizeFilter$ = new Subject<string|null>();
  constructor(public afAuth: AngularFireAuth, public db: AngularFirestore) {}

  updateTodaysDate() {
    this.db.collection('date').doc('1').update({name: this.currentTimestamp});
  };
  getTodaysDate() {
    return this.db.collection('date').doc('1').ref.get().then(date => {
      if (date.exists) {
        console.log('Today Date:', date.data());
        this.todayDate = (new Date(date.data().name.seconds*1000));
        console.log(this.todayDate);
        console.log(formatDate(new Date(this.todayDate), 'dd/MMM/yyyy', 'en'))
        console.log(this.todayDate.getDate())
      } else {
         console.log('No date document found!');
         // TODO : Logout Handler
      }
    }).catch(error => {
      console.log('Error getting date document, getTodaysDate:', error);
      // TODO : Logout Handler
    });
  };

   getUserLoginStatus() {
    const promise = new Promise((resolve, reject) => {
      this.afAuth.authState.subscribe(user => {
        if (user) {
          this.userDetails = user;
          this.updateTodaysDate();
          resolve();
        } else {
          reject();
        }
      });
    });
    return promise;
  }

  userInitialization(){
    return this.db.collection('users').doc(this.userDetails.email).ref.get().then(doc => {
      if (doc.exists) {
        console.log('Document data:', doc.data());
      } else {
         console.log('No such document!');
         this.createUserRecord();
      }
      
    }).catch(error => {
      console.log('Error getting document, userInitialization:', error);
    });
  }

  createUserRecord() {
    console.log('Creating User Record');
    let user = this.userDetails;
    if(user.email == 'satyawan.chorge@gmail.com' || user.email == 'satyawanchorge@gmail.com'){
      this.userRecord = {name: user.displayName, role : 'admin', email: user.email, rank: 1, points: 0, date: this.currentTimestamp};
    } else{
      this.userRecord = {name: user.displayName, role : 'contestant', email: user.email, rank: 1, points: 0, date: this.currentTimestamp};
    }
    this.db.collection('users').doc(user.email).set(this.userRecord);
  }

  fetchQuery() {
    this.queryObservable = this.sizeFilter$.pipe(
      switchMap(size =>
        this.db.collection('users', ref => ref.where('email', '==', size)).snapshotChanges()
      )
    );
    this.queryObservable.subscribe(result => {
      console.log(result);
    });
    this.sizeFilter$.next('test@mail.com');
  }

  doGoogleLogin() {
    const provider = new firebase.auth.GoogleAuthProvider();
    provider.addScope('profile');
    provider.addScope('email');
    this.afAuth.auth.signInWithRedirect(provider);
  }

  doLogout() {
    const promise = new Promise((resolve, reject) => {
      if (firebase.auth().currentUser) {
        this.afAuth.auth.signOut().then(() => {
            resolve();
        }).catch(err => {
            reject(err);
        });
      } else {
          reject();
      }
    });
    return promise;
  }

  getUsersList(): any {
    this.allUsersFirestoreCollection = this.db.collection('users', ref => ref.where('email', '==', 'ravindra.chorge@gmail.com'));
    this.allUsersFirestoreCollection.snapshotChanges().pipe(
      map(changes =>
        changes.map(c =>
          ({ key: c.payload.doc.id, ...c.payload.doc.data() })
        )
      )
    ).subscribe(users => {
      this.users = users;
      console.log(this.users);
    });
    return this.users;
  }

}
